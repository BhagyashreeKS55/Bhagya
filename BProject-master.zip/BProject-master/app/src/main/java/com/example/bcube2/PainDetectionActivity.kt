package com.example.bcube2

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.*
import android.content.pm.PackageManager
import android.util.Log

class PainDetectionActivity : AppCompatActivity() {

    private lateinit var takePictureButton: Button
    private lateinit var uploadImageButton: Button
    private lateinit var displayImageView: ImageView
    private lateinit var diagnosisResult: TextView
    private lateinit var imagePathResult: TextView
    private lateinit var resultButton: Button

    private var currentPhotoUri: Uri? = null

    private val takePictureResult = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            displayImageView.setImageURI(currentPhotoUri)
            diagnosisResult.text = "Image captured. Analyzing pain..."
            analyzePain(currentPhotoUri)
        } else {
            Toast.makeText(this, "Failed to capture image", Toast.LENGTH_SHORT).show()
        }
    }

    private val uploadImageResult = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) {
            displayImageView.setImageURI(uri)
            diagnosisResult.text = "Image uploaded. Analyzing image..."
            val imagePath = getImagePath(uri)
            imagePathResult.visibility = TextView.VISIBLE
            imagePathResult.text = "Selected Image Path: $imagePath"
            resultButton.visibility = Button.VISIBLE // Show result button after selecting image path
            analyzePain(uri)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pain_detection)

        takePictureButton = findViewById(R.id.takePictureButton)
        uploadImageButton = findViewById(R.id.uploadImageButton)
        displayImageView = findViewById(R.id.displayImageView)
        diagnosisResult = findViewById(R.id.diagnosisResult)
        imagePathResult = findViewById(R.id.imagePathResult)
        resultButton = findViewById(R.id.resultButton)

        takePictureButton.setOnClickListener {
            if (checkPermissions()) {
                dispatchTakePictureIntent()
            } else {
                requestPermissions()
            }
        }

        uploadImageButton.setOnClickListener {
            uploadImageResult.launch("image/*")
        }

        resultButton.setOnClickListener {
            Toast.makeText(this, "Showing result...", Toast.LENGTH_SHORT).show()
        }
    }

    private fun checkPermissions(): Boolean {
        val cameraPermission = ContextCompat.checkSelfPermission(this, android.Manifest.permission.CAMERA)
        val storagePermission = ContextCompat.checkSelfPermission(this, android.Manifest.permission.READ_EXTERNAL_STORAGE)
        val writeStoragePermission = ContextCompat.checkSelfPermission(this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE)

        return cameraPermission == PackageManager.PERMISSION_GRANTED &&
                storagePermission == PackageManager.PERMISSION_GRANTED &&
                writeStoragePermission == PackageManager.PERMISSION_GRANTED
    }

    private fun requestPermissions() {
        ActivityCompat.requestPermissions(
            this,
            arrayOf(android.Manifest.permission.CAMERA, android.Manifest.permission.READ_EXTERNAL_STORAGE, android.Manifest.permission.WRITE_EXTERNAL_STORAGE),
            100
        )
    }

    private fun dispatchTakePictureIntent() {
        val takePictureIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        if (takePictureIntent.resolveActivity(packageManager) != null) {
            try {
                val photoUri: Uri = createImageUri()
                takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoUri)
                currentPhotoUri = photoUri
                takePictureResult.launch(takePictureIntent)
            } catch (ex: IOException) {
                Toast.makeText(this, "Error creating file for image", Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(this, "No camera app available", Toast.LENGTH_SHORT).show()
        }
    }

    private fun createImageUri(): Uri {
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "pain_detection_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())}.jpg")
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/PainDetectionApp")
        }
        return contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            ?: throw IOException("Failed to create image Uri")
    }

    private fun getImagePath(uri: Uri): String? {
        val projection = arrayOf(MediaStore.Images.Media.DATA)
        contentResolver.query(uri, projection, null, null, null)?.use { cursor ->
            val columnIndex = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA)
            cursor.moveToFirst()
            return cursor.getString(columnIndex)
        }
        return null
    }

    private fun analyzePain(imageUri: Uri?) {
        // Mocking analysis process for demonstration
        diagnosisResult.text = "Pain analysis complete. Result: No major issues detected."
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 100 && grantResults.all { it == PackageManager.PERMISSION_GRANTED }) {
            dispatchTakePictureIntent()
        } else {
            Toast.makeText(this, "Permissions denied. Cannot take picture.", Toast.LENGTH_SHORT).show()
        }
    }
}
