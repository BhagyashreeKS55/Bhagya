package com.example.bcube2

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.ImageButton

class AboutUsActivity : AppCompatActivity() {

    private lateinit var backButton: ImageButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.about_us)

        // Back button to navigate to the previous screen
        backButton = findViewById(R.id.backButton)
        backButton.setOnClickListener {
            onBackPressed() // Go back to the previous activity
        }
    }
}
