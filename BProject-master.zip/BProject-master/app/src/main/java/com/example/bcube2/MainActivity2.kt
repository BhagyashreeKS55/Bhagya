package com.example.bcube2

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity2 : AppCompatActivity() {

    private lateinit var etName: EditText
    private lateinit var etPassword: EditText // Change to password
    private lateinit var btnProceed: Button
    private lateinit var tvTermsandCondition4: TextView
    private lateinit var tvTermsandCondition: TextView

    private lateinit var sharedPreferences: SharedPreferences
    private val PREF_NAME = "UserPrefs"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)

        etName = findViewById(R.id.etName)
        etPassword = findViewById(R.id.etPassword) // Change to password EditText
        btnProceed = findViewById(R.id.btnProceed)
        tvTermsandCondition4 = findViewById(R.id.tvTermsandCondition4)
        tvTermsandCondition = findViewById(R.id.tvTermsandCondition)

        // Initialize SharedPreferences
        sharedPreferences = getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)

        btnProceed.setOnClickListener {
            if (validateFields()) {
                val savedUsername = sharedPreferences.getString("username", null)
                val savedPassword = sharedPreferences.getString("password", null) // Fetch saved password

                // Trim input values for comparison
                val enteredUsername = etName.text.toString().trim()
                val enteredPassword = etPassword.text.toString().trim() // Fetch entered password

                // Logging retrieved values for debugging
                Log.d("SignIn", "Saved username: $savedUsername, saved password: $savedPassword")
                Log.d("SignIn", "Entered username: $enteredUsername, entered password: $enteredPassword")

                // Check if entered details match with saved details
                if (enteredUsername == savedUsername && enteredPassword == savedPassword) {
                    showToast("Sign-in successful")
                    // Proceed to the next activity after successful sign-in
                    val intent = Intent(this@MainActivity2, MainActivity4::class.java)
                    startActivity(intent)
                    finish()
                } else {
                    showToast("Invalid username or password")
                }
            }
        }

        tvTermsandCondition.setOnClickListener {
            val intent = Intent(this@MainActivity2, MainActivity::class.java)
            startActivity(intent)
            finish()
        }

        tvTermsandCondition4.setOnClickListener {
            val intent = Intent(this@MainActivity2, MainActivity3::class.java)
            startActivity(intent)
            finish()
        }
    }

    private fun validateFields(): Boolean {
        val name = etName.text.toString().trim()
        val password = etPassword.text.toString().trim() // Get password input

        if (name.isEmpty()) {
            etName.error = "Please enter your username"
            return false
        }

        if (password.isEmpty()) {
            etPassword.error = "Please enter your password" // Error for password
            return false
        }

        return true
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}
