package com.example.bcube2

import android.content.Intent
import android.os.Bundle
import android.util.Patterns
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth

class MainActivity3 : AppCompatActivity() {
    private lateinit var etEmail: EditText
    private lateinit var btnForgotPassword: Button
    private lateinit var textViewForgotPassword: TextView
    private lateinit var tvBack2: TextView
    private lateinit var mAuth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main3)

        // Initialize FirebaseAuth
        mAuth = FirebaseAuth.getInstance()

        etEmail = findViewById(R.id.etEmail)
        btnForgotPassword = findViewById(R.id.btnForgotPassword)
        textViewForgotPassword = findViewById(R.id.textView2)
        tvBack2 = findViewById(R.id.tvBack2)  // Initialize tvBack2

        // Set up the Forgot Password button functionality
        btnForgotPassword.setOnClickListener {
            val email = etEmail.text.toString().trim()

            if (email.isEmpty()) {
                showToast("Please fill in the email field")
                return@setOnClickListener
            }

            if (isValidEmail(email) && email.endsWith("@gmail.com")) {
                // Call Firebase to send password reset link
                sendPasswordResetEmail(email)
            } else {
                showToast("Please enter a valid Gmail address")
            }
        }

        // Navigate back to MainActivity2 when textViewForgotPassword is clicked
        textViewForgotPassword.setOnClickListener {
            val intent = Intent(this, MainActivity2::class.java)
            startActivity(intent)
            finish()  // Optional: close MainActivity3 after navigation
        }

        // Navigate back to MainActivity2 when tvBack2 is clicked
        tvBack2.setOnClickListener {
            val intent = Intent(this, MainActivity2::class.java)
            startActivity(intent)
            finish()  // Optional: close MainActivity3 after navigation
        }
    }

    // Function to send password reset email via Firebase
    private fun sendPasswordResetEmail(email: String) {
        mAuth.sendPasswordResetEmail(email)
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    showToast("Password reset link sent to your email")
                } else {
                    showToast("Error sending password reset link. Please try again.")
                }
            }
    }

    // Function to check if the entered email is valid
    private fun isValidEmail(email: String): Boolean {
        return Patterns.EMAIL_ADDRESS.matcher(email).matches()
    }

    // Function to show Toast messages
    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}
