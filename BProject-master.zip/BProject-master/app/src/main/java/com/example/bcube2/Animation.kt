package com.example.bcube2

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.view.View
import android.widget.ImageView
import android.widget.ProgressBar
import androidx.appcompat.app.AppCompatActivity

class Animation : AppCompatActivity() {

    private lateinit var imageView4: ImageView
    private lateinit var progressBar: ProgressBar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.anime)

        imageView4 = findViewById(R.id.imageView4)
        progressBar = findViewById(R.id.progressBar)
        progressBar.visibility = View.VISIBLE


        Handler().postDelayed({
            progressBar.visibility = View.GONE

            val intent = Intent(this@Animation, MainActivity2::class.java)
            startActivity(intent)
            finish()
        }, 3000)
    }
}
