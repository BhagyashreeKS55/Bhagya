package com.example.bcube2

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.text.InputType
import android.util.Log
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var etNewUsername: EditText
    private lateinit var etNewEmail: EditText
    private lateinit var etNewPassword: EditText
    private lateinit var etConfirmPassword: EditText
    private lateinit var btnSignUp: Button
    private lateinit var checkBox: CheckBox
    private lateinit var ivPasswordToggle: ImageView
    private lateinit var ivPasswordToggle1: ImageView
    private lateinit var tvBack: TextView

    private var isPasswordVisible1 = false
    private var isPasswordVisible2 = false

    private lateinit var sharedPreferences: SharedPreferences
    private val PREF_NAME = "UserPrefs"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        etNewUsername = findViewById(R.id.etNewUsername)
        etNewEmail = findViewById(R.id.etNewEmail)
        etNewPassword = findViewById(R.id.etNewPassword)
        etConfirmPassword = findViewById(R.id.etNewPassword1)
        btnSignUp = findViewById(R.id.btnSignUp)
        checkBox = findViewById(R.id.checkBox)
        ivPasswordToggle = findViewById(R.id.ivPasswordToggle)
        ivPasswordToggle1 = findViewById(R.id.ivPasswordToggle1)
        tvBack = findViewById(R.id.tvBack)

        sharedPreferences = getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)

        ivPasswordToggle1.setOnClickListener {
            isPasswordVisible1 = !isPasswordVisible1
            updatePasswordVisibility()
        }

        ivPasswordToggle.setOnClickListener {
            isPasswordVisible2 = !isPasswordVisible2
            updatePasswordVisibility()
        }

        tvBack.setOnClickListener {
            // Navigate back to MainActivity2
            val intent = Intent(this@MainActivity, MainActivity2::class.java)
            startActivity(intent)
            finish() // Optionally, close the current activity
        }

        btnSignUp.setOnClickListener {
            if (validateFields()) {
                if (checkBox.isChecked) {
                    saveUserDetails()
                    clearFields()
                    val intent = Intent(this@MainActivity, MainActivity2::class.java)
                    startActivity(intent)
                    finish()
                } else {
                    showToast("Please agree to the Terms and Conditions")
                }
            } else {
                showToast("Please fill in all fields correctly")
            }
        }
    }

    private fun updatePasswordVisibility() {
        etNewPassword.inputType = if (isPasswordVisible1) {
            InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
        } else {
            InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }

        etConfirmPassword.inputType = if (isPasswordVisible2) {
            InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
        } else {
            InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }

        etNewPassword.setSelection(etNewPassword.text.length)
        etConfirmPassword.setSelection(etConfirmPassword.text.length)
    }

    private fun validateFields(): Boolean {
        return etNewUsername.text.isNotBlank() &&
                etNewEmail.text.isNotBlank() &&
                etNewPassword.text.isNotBlank() &&
                etConfirmPassword.text.isNotBlank() &&
                etNewPassword.text.toString() == etConfirmPassword.text.toString()
    }

    private fun saveUserDetails() {
        val username = etNewUsername.text.toString().trim()
        val email = etNewEmail.text.toString().trim()
        val password = etNewPassword.text.toString().trim() // Store securely if needed

        val editor = sharedPreferences.edit()
        editor.putString("username", username)
        editor.putString("email", email)
        editor.putString("password", password)  // Consider encrypting this
        editor.apply()

        // Logging saved user details
        Log.d("SignUp", "Saved username: $username, email: $email, password: $password")

        showToast("User details saved successfully!")
    }

    private fun clearFields() {
        etNewUsername.text.clear()
        etNewEmail.text.clear()
        etNewPassword.text.clear()
        etConfirmPassword.text.clear()
        checkBox.isChecked = false
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}
