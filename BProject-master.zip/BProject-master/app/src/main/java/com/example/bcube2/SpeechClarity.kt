package com.example.bcube2

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.OpenableColumns
import android.util.Log
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.io.IOException
import java.util.*
class SpeechClarity : AppCompatActivity() {
    private var recordButton: Button? = null
    private var uploadButton: Button? = null
    private var playButton: Button? = null
    private var getResultButton: Button? = null
    private var speechResult: TextView? = null
    private var deselectButton: ImageView? = null
    private var selectedAudioUri: Uri? = null

    private var mediaRecorder: MediaRecorder? = null
    private var mediaPlayer: MediaPlayer? = null
    private var audioFilePath: String? = null
    private var isRecording = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.speechclarity)

        recordButton = findViewById(R.id.recordButton)
        uploadButton = findViewById(R.id.uploadButton)
        playButton = findViewById(R.id.playButton)
        getResultButton = findViewById(R.id.resultButton)
        speechResult = findViewById(R.id.speechResult)
        deselectButton = findViewById(R.id.deselectButton)

        // Initially disable the Get Result button
        getResultButton?.isEnabled = false

        recordButton?.setOnClickListener {
            if (isRecording) {
                stopRecording()
            } else {
                startRecording()
            }
        }

        uploadButton?.setOnClickListener {
            openAudioFilePicker()
        }

        playButton?.setOnClickListener {
            playSelectedAudio()
        }

        getResultButton?.setOnClickListener {
            if (selectedAudioUri != null || audioFilePath != null) {
                showToast("Getting result for the selected or recorded audio file.")
            } else {
                showToast("Please select or record an audio file first")
            }
        }

        deselectButton?.setOnClickListener {
            selectedAudioUri = null
            speechResult?.text = ""
            deselectButton?.visibility = ImageView.GONE
            getResultButton?.text = "Get Result"
            getResultButton?.isEnabled = false
            showToast("Audio file deselected")
        }
    }

    private fun startRecording() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            val audioDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            val fileName = "audio_${UUID.randomUUID()}.m4a"
            audioFilePath = "${audioDir.absolutePath}/$fileName"
            Log.d("AudioFilePath", audioFilePath ?: "Path is null")

            mediaRecorder = MediaRecorder().apply {
                setAudioSource(MediaRecorder.AudioSource.MIC)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                setOutputFile(audioFilePath)
                try {
                    prepare()
                    start()
                    isRecording = true
                    recordButton?.text = "Stop Recording"
                    showToast("Recording started")
                } catch (e: IOException) {
                    e.printStackTrace()
                    showToast("Recording failed")
                }
            }
        } else {
            showToast("Please allow audio recording permission")
        }
    }

    private fun stopRecording() {
        mediaRecorder?.apply {
            stop()
            release()
        }
        mediaRecorder = null
        isRecording = false
        recordButton?.text = "Start Recording"
        showToast("Recording saved at: $audioFilePath")
        // Enable Get Result button after recording is saved
        getResultButton?.isEnabled = true
        getResultButton?.text = "Get Result"
    }

    private fun openAudioFilePicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            type = "audio/*"
            addCategory(Intent.CATEGORY_OPENABLE)
        }
        audioPickerLauncher.launch(intent)
    }

    private val audioPickerLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val data: Intent? = result.data
            data?.data?.also { uri ->
                selectedAudioUri = uri
                val fileName = getFileName(uri)
                speechResult?.text = fileName
                showToast("Audio file selected: $fileName")

                // Show the deselect icon and enable Get Result button
                deselectButton?.visibility = ImageView.VISIBLE
                getResultButton?.text = "Get Result"
                getResultButton?.isEnabled = true
            }
        }

    private fun getFileName(uri: Uri): String? {
        var fileName: String? = null
        contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            cursor.moveToFirst()
            fileName = cursor.getString(nameIndex)
        }
        return fileName
    }

    private fun playSelectedAudio() {
        if (selectedAudioUri != null) {
            playAudio(selectedAudioUri!!)
        } else if (audioFilePath != null) {
            playAudio(Uri.parse(audioFilePath))
        } else {
            showToast("Please select or record an audio file to play")
        }
    }

    private fun playAudio(uri: Uri) {
        try {
            mediaPlayer = MediaPlayer().apply {
                setDataSource(this@SpeechClarity, uri)
                prepareAsync()
                setOnPreparedListener {
                    start()
                    showToast("Audio is playing")
                }
                setOnCompletionListener {
                    release()
                }
            }
        } catch (e: IOException) {
            e.printStackTrace()
            showToast("Unable to play audio")
        }
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}