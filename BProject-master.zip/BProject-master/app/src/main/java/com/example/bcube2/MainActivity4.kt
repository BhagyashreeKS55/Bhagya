package com.example.bcube2

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Button
import android.widget.TextView
import android.widget.ViewFlipper
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView

class MainActivity4 : AppCompatActivity() {

    private lateinit var speechClarityButton: Button
    private lateinit var painDetectionButton: Button
    private lateinit var appIntroduction: TextView
    private lateinit var sliderViewFlipper: ViewFlipper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main4)
        supportActionBar?.title = "Dashboard"

        // Initialize UI elements
        speechClarityButton = findViewById(R.id.speechClarityButton)
        painDetectionButton = findViewById(R.id.painDetectionButton)
        appIntroduction = findViewById(R.id.appIntroduction)
        sliderViewFlipper = findViewById(R.id.sliderViewFlipper)  // Initialize once here

        // Set introductory text
        appIntroduction.text = "Our app enhances speech clarity for individuals with cerebral palsy and detects pain through image analysis. Choose an option to get started."

        // Configure slider
        sliderViewFlipper.flipInterval = 5000 // Slide duration in milliseconds
        sliderViewFlipper.startFlipping() // Start auto-sliding

        // Button click listeners
        speechClarityButton.setOnClickListener {
            val intent = Intent(this, SpeechClarity::class.java)
            startActivity(intent)
        }

        painDetectionButton.setOnClickListener {
            val intent = Intent(this, PainDetectionActivity::class.java)
            startActivity(intent)
        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.menu_about_us -> {
                val intent = Intent(this, AboutUsActivity::class.java)
                startActivity(intent)
                true
            }

            R.id.menu_logout -> {
                val intent = Intent(this, MainActivity2::class.java)
                startActivity(intent)
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
}